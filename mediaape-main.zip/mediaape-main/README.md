# MediaApe

## !!! THIS REPO DOES NOT HAVE ***ANY*** GAMES IN IT !!!

![Monkeys spinning and holding hands.](content/img/monkeys-spinning-and-holding-hands.gif)

> "Create, explore, expand, conquer" - A$AP Rocky

MediaApe is an unblocked games website created by Teker in 2021. We've had a long history, but here we are; Version 5.

# Basil

Basil is a new system for the image that appears when you open MediaApe. It works by generating a random number between 1 and 1000, it will then use a `switch` statement to find out what image it should display. You can also set that number by typing `setBasilNum(num)` in the console (replace num with your number).